package mypack;

import javax.persistence.*;

@Entity
@Table(name="stdname")
public class formDB 
{
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int stdid;

	@Column(name="stname")
	private String stname;
	
	@Column(name="dob")
	private int dob;
	
	@Column(name="gender")
	private char gender;
	
	@Column(name="placebirth")
	private String placebirth;
	
	@Column(name="nationality")
	private String nationality;
	
	@Column(name="firstlang")
	private String firstlang;
	
	@Column(name="secondlang")
	private String secondlang;
	
	@Column(name="addre")
	private String addre;
	
	@Column(name="fname")
	private String fname;
	
	@Column(name="fmail")
	private String fmail;
	
	@Column(name="fphone")
	private int fphone;
	
	
	@Column(name="mname")
	private String mname;
	
	
	@Column(name="mmail")
	private String mmail;
	
	@Column(name="mphone")
	private int mphone;
	
	@Column(name="emfname")
	private String emfname;
	
	@Column(name="emfphone")
	private int emfphone;
	
	@Column(name="emsname")
	private String emsname;
	
	@Column(name="emsphone")
	private int emsphone;
	
	@Column(name="emtname")
	private String emname;
	
	@Column(name="emtphone")
	private int emtphone;

	public int getStdid() {
		return stdid;
	}

	public void setStdid(int stdid) {
		this.stdid = stdid;
	}

	public String getStname() {
		return stname;
	}

	public void setStname(String stname) {
		this.stname = stname;
	}

	public int getDob() {
		return dob;
	}

	public void setDob(int dob) {
		this.dob = dob;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getPlacebirth() {
		return placebirth;
	}

	public void setPlacebirth(String placebirth) {
		this.placebirth = placebirth;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getFirstlang() {
		return firstlang;
	}

	public void setFirstlang(String firstlang) {
		this.firstlang = firstlang;
	}

	public String getSecondlang() {
		return secondlang;
	}

	public void setSecondlang(String secondlang) {
		this.secondlang = secondlang;
	}

	public String getAddre() {
		return addre;
	}

	public void setAddre(String addre) {
		this.addre = addre;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getFmail() {
		return fmail;
	}

	public void setFmail(String fmail) {
		this.fmail = fmail;
	}

	public int getFphone() {
		return fphone;
	}

	public void setFphone(int fphone) {
		this.fphone = fphone;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getMmail() {
		return mmail;
	}

	public void setMmail(String mmail) {
		this.mmail = mmail;
	}

	public int getMphone() {
		return mphone;
	}

	public void setMphone(int mphone) {
		this.mphone = mphone;
	}

	public String getEmfname() {
		return emfname;
	}

	public void setEmfname(String emfname) {
		this.emfname = emfname;
	}

	public int getEmfphone() {
		return emfphone;
	}

	public void setEmfphone(int emfphone) {
		this.emfphone = emfphone;
	}

	public String getEmsname() {
		return emsname;
	}

	public void setEmsname(String emsname) {
		this.emsname = emsname;
	}

	public int getEmsphone() {
		return emsphone;
	}

	public void setEmsphone(int emsphone) {
		this.emsphone = emsphone;
	}

	public String getEmname() {
		return emname;
	}

	public void setEmname(String emname) {
		this.emname = emname;
	}

	public int getEmtphone() {
		return emtphone;
	}

	public void setEmtphone(int emtphone) {
		this.emtphone = emtphone;
	}
		
}
